# workshop-examples
Ansible Workshop Example Playbooks for Security Automation
